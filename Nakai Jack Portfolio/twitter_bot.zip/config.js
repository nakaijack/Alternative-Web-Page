
module.exports = {
  consumer_key:         'yATcyg9G4hFC3b4H4ZxWoNNaf',
  consumer_secret:      '7wEge5YVbqLkp5qmWia5J5S2ZxlI8zASOxr9sDfpusioypECko',
  access_token:         '1234945392644513792-kPmdpNgMea9l6dUniOrOGw5GzYtoJg',
  access_token_secret:  'LXvwFuugRJMnjVknqifSn1MTQckQd1foKH86i8QvGNLYP'
}
