This twitter bot like, retweets, replies, and post tweets regarding final exams to provide some moral support.
By Nikkai and Roni
LMC 2700 Intro to Computational Media
Professor Firaz Peer
Georgia Tech